from flask import Flask, request
import subprocess
import urllib.parse

app = Flask(__name__)

@app.route('/open-model')
def open_model():
    model_path = request.args.get('path')
    if not model_path:
        return "Model path not provided.", 400

    # Decode URL-encoded path
    model_path = urllib.parse.unquote(model_path)

    try:
        # Launch MATLAB and open the model
        subprocess.Popen([
            "matlab",
            "-r",
            f"open_system('{model_path}');"
        ])
        return f"Opening model: {model_path}", 200
    except Exception as e:
        return f"Error: {str(e)}", 500

if __name__ == '__main__':
    app.run(port=5000)
